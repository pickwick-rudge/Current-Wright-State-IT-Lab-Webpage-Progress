var scale = Math.min(
	availableWidth / contentWidth,
	availableHeight / contentHeight
);